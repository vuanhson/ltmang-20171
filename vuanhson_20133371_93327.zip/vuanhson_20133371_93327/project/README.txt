chay cac lenh sau: 
make

Server side:
./server <Server Port>
Vi du:
./server 2311

Client side:
./client <che do> <duong dan den file> <IP server> <Server Port>
vi du:  
./client encode client-file/test.txt 127.0.0.1 2311
./client decode client-file/test.txt 127.0.0.1 2311

file tra ve tu server se nam trong folder: client-file/ketqua_<thoi gian sinh ra file>.txt

